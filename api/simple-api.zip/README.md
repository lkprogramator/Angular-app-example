
## Simple Rest api

 * Copy simple-api folder outside the project
 * Run `npm install` to install dependecies.
 * Run `npm run simpleApi` to run the server.
 * Navigate to `http://localhost:3004/`



