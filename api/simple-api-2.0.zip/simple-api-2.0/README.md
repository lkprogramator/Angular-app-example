
## Simple Rest api

 * Copy simple-api folder outside the project
 * Run `npm install` to install dependecies.
 * Run `npm run authApi` to run the server.
 * Navigate to `http://localhost:3004/`



